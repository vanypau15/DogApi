const express = require('express');

const router = express.Router();

// Example route: Get all dogs
router.get('/dogs', (req, res) => {
    // Replace with actual logic to fetch dogs from database
    res.json([{ id: 1, name: 'Buddy' }, { id: 2, name: 'Bella' }]);
});

// Example route: Add a new dog
router.post('/dogs', (req, res) => {
    // Replace with logic to add a new dog
    const newDog = req.body;
    res.status(201).json(newDog);
});

module.exports = router;