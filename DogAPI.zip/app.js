const express = require('express');
const {ObjectId} = require('mongodb');
const {connectToDb, getDb} = require('./db');

// init app & middleware
const app = express();

// connect to db
let db
connectToDb((err) => {
    if (!err) {
        app.listen(3000, () => {
  console.log('Server is running on port 3000');
})
        db = getDb();
} 
})


// routes
app.get('/dogs', (req, res) => {
    let dogs = [];
    db.collection('dogs')
        .find() // cursor
        .sort({breed: 1}) // sort by breed
        .forEach(dog => dogs.push(dog)) // push each dog into the array
        .then(() => {
            res.status(200).json(dogs);
        })
        .catch(() => {
            res.status(500).json({error: 'Could not fetch the dogs'});
})
    
});

app.get('/dogs/:id', (req, res) => {
    if (ObjectId.isValid(req.params.id)) {
    db.collection('dogs')
        .findOne({_id: ObjectId(req.params.id)}) // find one dog by id
        .then(dog => {
            res.status(200).json(dog);
        })
        .catch(() => {
            res.status(500).json({error: 'Could not fetch the dog'});
        });
}   else {
    res.status(500).json({error: 'Invalid ID format'});
}
}
);
