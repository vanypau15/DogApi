const mongoose = require('mongoose');

const dogSchema = new mongoose.Schema({
    name: { type: String, required: true },
    breed: { type: String, required: true },
    age: { type: Number, required: true },
    adopted: { type: Boolean, default: false },
    description: { type: String },
    imageUrl: { type: String }
}, { timestamps: true });

const adopterSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    phone: { type: String },
    adoptedDogs: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Dog' }]
}, { timestamps: true });

const Dog = mongoose.model('Dog', dogSchema);
const Adopter = mongoose.model('Adopter', adopterSchema);

module.exports = { Dog, Adopter };