/**
 * Custom middleware functions for the Dog Adoption API.
 * Add authentication, rate limiting, and other middleware here.
 */

// Example authentication middleware
function authenticate(req, res, next) {
    // Replace with real authentication logic
    const token = req.headers['authorization'];
    if (token === 'your-secret-token') {
        next();
    } else {
        res.status(401).json({ error: 'Unauthorized' });
    }
}

// Example rate limiting middleware
let requestCounts = {};
const RATE_LIMIT = 100; // max requests per hour
const WINDOW_SIZE = 60 * 60 * 1000; // 1 hour in ms

function rateLimiter(req, res, next) {
    const ip = req.ip;
    const now = Date.now();

    if (!requestCounts[ip]) {
        requestCounts[ip] = [];
    }

    // Remove timestamps older than window size
    requestCounts[ip] = requestCounts[ip].filter(ts => now - ts < WINDOW_SIZE);

    if (requestCounts[ip].length >= RATE_LIMIT) {
        return res.status(429).json({ error: 'Too many requests' });
    }

    requestCounts[ip].push(now);
    next();
}

module.exports = {
    authenticate,
    rateLimiter,
};